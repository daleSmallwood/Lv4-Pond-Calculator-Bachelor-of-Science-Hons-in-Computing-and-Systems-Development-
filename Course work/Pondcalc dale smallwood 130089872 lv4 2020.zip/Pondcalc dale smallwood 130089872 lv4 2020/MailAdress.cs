﻿namespace Pondcalc_dale_smallwood_130089872_lv4_2020
{
    internal class MailAdress
    {
        private string clientEmail;

        public MailAdress(string clientEmail)
        {
            this.clientEmail = clientEmail;
        }
    }
}